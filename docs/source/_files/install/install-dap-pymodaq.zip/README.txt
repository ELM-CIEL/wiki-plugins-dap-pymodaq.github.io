========================================================================
 Package d'installation - Plugins PyMoDAQ DAP (Raspberry unifie + Arduino)
========================================================================

CE QUE FAIT CE PACKAGE
----------------------
Le script "Install.bat" installe automatiquement :
  - l'environnement conda "Py26" (depuis files/Py26env.yml) ;
  - le plugin Raspberry unifie et le plugin Arduino (pip install -e) ;
  - les fichiers de configuration (.toml) dans %USERPROFILE%\.pymodaq ;
  - les presets (.xml) dans C:\ProgramData\.pymodaq\preset_configs.

AVANT DE LANCER
---------------
1. Decompressez TOUT le zip dans un dossier (n'importe ou).
2. (Recommande) Editez les fichiers du sous-dossier "files" selon votre materiel :
     - files/config_raspberry.toml et files/config_arduino.toml
       -> remplacez les adresses IP (et les broches si besoin) par les votres ;
     - files/Raspberry.xml et files/Arduino.xml (presets) -> adaptez l'IP si besoin.

INSTALLATION
------------
- Double-cliquez sur "Install.bat".
- Un menu permet de (de)cocher les actions ; appuyez sur G pour lancer.
- Prerequis : Miniconda ou Anaconda installe (commande "conda").

REMARQUE IMPORTANTE - PRESET RASPBERRY
--------------------------------------
Le preset "Raspberry.xml" a ete ADAPTE depuis l'ancien preset Raspberry Pi 3 vers le
plugin unifie (classes MoveRasp / ViewRasp). Il est fourni comme point de depart :
VERIFIEZ qu'il se charge correctement dans PyMoDAQ et, au besoin, recreez-le
(Preset Mode -> New preset -> DAQ_Move MoveRasp + DAQ_Viewer ViewRasp).

CONTENU
-------
  Install.bat              ce lanceur (double-clic)
  README.txt               ce fichier
  files/
    Py26env.yml                  environnement conda
    config_raspberry.toml        config exemple (plugin Raspberry unifie)
    config_arduino.toml          config exemple (plugin Arduino)
    Raspberry.xml                preset (A VERIFIER)
    Arduino.xml                  preset
    pymodaq_plugins_raspberry/   sources du plugin Raspberry unifie
    pymodaq-plugins-arduino/     sources du plugin Arduino
